class GradleException {
    GradleException(java.lang.String string) {

    }
}
